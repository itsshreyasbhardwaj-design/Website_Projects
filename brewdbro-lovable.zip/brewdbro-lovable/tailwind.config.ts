import type { Config } from "tailwindcss";

export default {
  content: ["./index.html", "./src/**/*.{ts,tsx}"],
  theme: {
    extend: {
      colors: {
        cream: "#faf5e8",
        foam: "#fffdf8",
        latte: "#efe6d3",
        sand: "#e2d6bd",
        flame: { DEFAULT: "#ff4500", deep: "#d93a00" },
        teal: { DEFAULT: "#005c61", deep: "#00474b" },
        mocha: "#6f4e37",
        roast: "#3a2418",
        espresso: "#261611",
        char: "#160c08",
        taupe: "#6f5d4e",
        berry: "#dc2626",
        // product-material accents
        blush: "#d98a8f",
        lilac: "#bfa9dd",
        mint: "#a8e6cf",
      },
      fontFamily: {
        display: ["Outfit", "system-ui", "sans-serif"],
        sans: ["'DM Sans'", "system-ui", "sans-serif"],
        mono: ["'Space Mono'", "ui-monospace", "monospace"],
        serif: ["Fraunces", "Georgia", "serif"],
      },
    },
  },
  plugins: [],
} satisfies Config;
