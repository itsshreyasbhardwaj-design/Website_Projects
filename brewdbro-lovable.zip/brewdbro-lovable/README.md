# BrewdBro — Vite + React (Lovable-ready)

Premium 3D coffee D2C storefront for **BrewdBro** — *Just Brew It Bro!*
Ported from Next.js to a **Vite + React + TypeScript + Tailwind** stack so it imports
and edits cleanly in **Lovable**.

## Stack
- **Vite + React 19 + TypeScript**
- **Tailwind CSS v3** (config in `tailwind.config.ts`, tokens also in `src/index.css`)
- **React Router** for pages
- **React Three Fiber + drei** — the scroll-driven exploded 3D tumbler (`src/components/three/`)
- **Framer Motion** (scroll/reveal animations) · **Zustand** (persistent cart)
- `@/` path alias → `src/` (configured in `vite.config.ts` + `tsconfig.app.json`)

## Run locally
```bash
npm install
npm run dev      # http://localhost:5173
npm run build    # production build to /dist
npm run preview  # preview the build
```

## How to open this in Lovable
Lovable syncs with **GitHub**, so:
1. Create a new GitHub repo and push this project:
   ```bash
   git init && git add -A && git commit -m "BrewdBro"
   git branch -M main
   git remote add origin https://github.com/<you>/brewdbro.git
   git push -u origin main
   ```
2. In Lovable → **New Project → Import from GitHub** (or connect GitHub and select the repo).
3. Lovable picks up the Vite + React + Tailwind setup and you can edit visually / with AI.

## Project map
```
src/
  pages/         Home, Shop, Product, Cart, Checkout, Success, Story (routes)
  components/     Nav, Footer, ProductCard, ProductBuyBox, Logo, CupGlyph, PouchGlyph, Reveal
    sections/     Hero (3D), Combo, ThreeCups, Ritual, Cinematic, SocialProof, BusinessStrip, FinalCTA
    three/        ExplodeCanvas + ExplodeTumbler (hero), HeroCanvas + Tumbler (product viewer)
  lib/            products.ts (catalogue), cart.ts (Zustand), format.ts, useTitle.ts
  index.css       brand tokens + component classes
public/
  logo.svg        brand mark (favicon + nav/footer)
  photos/         drop real product/lifestyle photos here (see README inside)
```

## Editing the basics
- **Products / prices:** `src/lib/products.ts`
- **Brand colors / fonts:** `tailwind.config.ts` + `src/index.css` (`:root` tokens)
- **Checkout:** demo Razorpay-style flow in `src/pages/Checkout.tsx` — swap in real Razorpay (key + order route) when ready.
- **Logo / pouch art:** recreated as SVG (`Logo.tsx`, `PouchGlyph.tsx`). Drop real PNGs in `public/` and point to them for pixel-perfect.
